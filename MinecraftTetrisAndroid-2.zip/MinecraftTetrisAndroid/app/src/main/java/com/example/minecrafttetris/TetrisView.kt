package com.example.minecrafttetris

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.os.Handler
import android.os.Looper
import kotlin.random.Random

class TetrisView(context: Context, private val onScore: (Int) -> Unit) : View(context) {
    private val cols = 10
    private val rows = 20
    private val board = Array(rows) { IntArray(cols) }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = Handler(Looper.getMainLooper())
    private val colors = intArrayOf(
        0xff55aaff.toInt(), 0xffffd34e.toInt(), 0xffbb77dd.toInt(),
        0xff55cc77.toInt(), 0xffdd6655.toInt(), 0xff55cccc.toInt(), 0xffdd9955.toInt()
    )
    private val shapes = arrayOf(
        arrayOf(intArrayOf(1,1,1,1)),
        arrayOf(intArrayOf(1,1), intArrayOf(1,1)),
        arrayOf(intArrayOf(0,1,0), intArrayOf(1,1,1)),
        arrayOf(intArrayOf(1,0,0), intArrayOf(1,1,1)),
        arrayOf(intArrayOf(0,0,1), intArrayOf(1,1,1)),
        arrayOf(intArrayOf(0,1,1), intArrayOf(1,1,0)),
        arrayOf(intArrayOf(1,1,0), intArrayOf(0,1,1))
    )
    private var shape = shapes[0]
    private var color = colors[0]
    private var x = 3
    private var y = 0
    private var score = 0
    private var paused = false
    private var over = false
    private var cell = 0f
    private var boardLeft = 0f
    private var boardTop = 0f
    private val tick = object : Runnable {
        override fun run() {
            if (!paused && !over) {
                if (!collides(x, y + 1, shape)) y++ else lockPiece()
                invalidate()
            }
            handler.postDelayed(this, (520L - (score / 500) * 35L).coerceAtLeast(110L))
        }
    }

    init {
        isFocusable = true
        spawn()
        handler.postDelayed(tick, 500)
    }

    private fun spawn() {
        val index = Random.nextInt(shapes.size)
        shape = shapes[index].map { it.copyOf() }.toTypedArray()
        color = colors[index]
        x = (cols - shape[0].size) / 2
        y = 0
        if (collides(x, y, shape)) over = true
    }

    private fun collides(nx: Int, ny: Int, s: Array<IntArray>): Boolean {
        for (r in s.indices) for (c in s[r].indices) if (s[r][c] != 0) {
            val bx = nx + c; val by = ny + r
            if (bx < 0 || bx >= cols || by >= rows) return true
            if (by >= 0 && board[by][bx] != 0) return true
        }
        return false
    }

    private fun lockPiece() {
        for (r in shape.indices) for (c in shape[r].indices) if (shape[r][c] != 0) {
            val by = y + r; val bx = x + c
            if (by in 0 until rows && bx in 0 until cols) board[by][bx] = color
        }
        var cleared = 0
        for (r in rows - 1 downTo 0) {
            if (board[r].all { it != 0 }) {
                for (k in r downTo 1) board[k] = board[k - 1].copyOf()
                board[0] = IntArray(cols)
                cleared++
            }
        }
        if (cleared > 0) {
            score += when (cleared) { 1 -> 100; 2 -> 300; 3 -> 500; else -> 800 }
            onScore(score)
        }
        spawn()
    }

    fun move(dx: Int) { if (!paused && !over && !collides(x + dx, y, shape)) { x += dx; invalidate() } }
    fun drop() {
        if (paused || over) return
        while (!collides(x, y + 1, shape)) y++
        lockPiece(); invalidate()
    }
    fun rotate() {
        if (paused || over) return
        val rotated = Array(shape[0].size) { r -> IntArray(shape.size) { c -> shape[shape.size - 1 - c][r] } }
        if (!collides(x, y, rotated)) shape = rotated
        invalidate()
    }
    fun togglePause() { if (!over) { paused = !paused; invalidate() } }
    fun pause() { paused = true }
    fun restart() {
        for (r in 0 until rows) board[r] = IntArray(cols)
        score = 0; onScore(0); over = false; paused = false; spawn(); invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        cell = minOf(w / (cols + 1.2f), h / rows)
        boardLeft = (w - cols * cell) / 2f
        boardTop = (h - rows * cell) / 2f
        paint.color = 0xff182718.toInt()
        canvas.drawRoundRect(RectF(boardLeft - 5, boardTop - 5, boardLeft + cols*cell + 5, boardTop + rows*cell + 5), 8f, 8f, paint)

        for (r in 0 until rows) for (c in 0 until cols) {
            val colorHere = board[r][c]
            drawBlock(canvas, c, r, if (colorHere == 0) 0xff263b27.toInt() else colorHere)
        }
        if (!over) for (r in shape.indices) for (c in shape[r].indices) if (shape[r][c] != 0) {
            drawBlock(canvas, x + c, y + r, color)
        }
        if (paused || over) {
            paint.color = 0xcc101810.toInt()
            canvas.drawRect(boardLeft, boardTop, boardLeft + cols*cell, boardTop + rows*cell, paint)
            paint.color = 0xfff1f5dc.toInt()
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = cell * 0.85f
            paint.typeface = android.graphics.Typeface.create("monospace", 1)
            canvas.drawText(if (over) "ИГРА ОКОНЧЕНА" else "ПАУЗА", w/2, h/2, paint)
            if (over) {
                paint.textSize = cell * 0.45f
                canvas.drawText("Нажми ЗАНОВО", w/2, h/2 + cell, paint)
            }
        }
    }

    private fun drawBlock(canvas: Canvas, col: Int, row: Int, base: Int) {
        val l = boardLeft + col * cell
        val t = boardTop + row * cell
        val inset = cell * 0.045f
        paint.color = base
        canvas.drawRect(l + inset, t + inset, l + cell - inset, t + cell - inset, paint)
        // Pixel-style highlights and shadows give blocks a voxel look.
        paint.color = lighten(base)
        canvas.drawRect(l + inset, t + inset, l + cell - inset, t + cell * 0.20f, paint)
        canvas.drawRect(l + inset, t + inset, l + cell * 0.18f, t + cell - inset, paint)
        paint.color = darken(base)
        canvas.drawRect(l + cell * 0.82f, t + inset, l + cell - inset, t + cell - inset, paint)
        canvas.drawRect(l + inset, t + cell * 0.82f, l + cell - inset, t + cell - inset, paint)
    }
    private fun lighten(c: Int): Int {
        fun ch(s: Int) = (((c shr s) and 255) * 1.22f).toInt().coerceAtMost(255)
        return android.graphics.Color.rgb(ch(16), ch(8), ch(0))
    }
    private fun darken(c: Int): Int {
        fun ch(s: Int) = (((c shr s) and 255) * 0.58f).toInt()
        return android.graphics.Color.rgb(ch(16), ch(8), ch(0))
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP && !paused && !over) {
            val dx = event.x - width / 2f
            when {
                event.y < height * 0.25f -> rotate()
                dx < -cell -> move(-1)
                dx > cell -> move(1)
                else -> drop()
            }
            performClick()
            return true
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
