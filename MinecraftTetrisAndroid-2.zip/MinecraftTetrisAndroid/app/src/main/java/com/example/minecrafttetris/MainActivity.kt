package com.example.minecrafttetris

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var game: TetrisView
    private lateinit var score: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(28, 42, 28)
        window.navigationBarColor = android.graphics.Color.rgb(18, 28, 18)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 14, 14, 14)
            setBackgroundColor(android.graphics.Color.rgb(35, 55, 35))
        }
        val title = TextView(this).apply {
            text = "▰ BLOCK TETRIS ▰"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(220, 245, 190))
            typeface = android.graphics.Typeface.create("monospace", android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 12)
        }
        score = TextView(this).apply {
            text = "СЧЁТ: 0"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(0, 4, 0, 8)
        }
        game = TetrisView(this) { value -> runOnUiThread { score.text = "СЧЁТ: $value" } }

        root.addView(title)
        root.addView(score)
        root.addView(game, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row1.addView(control("◀") { game.move(-1) })
        row1.addView(control("▼") { game.drop() })
        row1.addView(control("▶") { game.move(1) })
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row2.addView(control("↻ ПОВОРОТ") { game.rotate() })
        row2.addView(control("Ⅱ ПАУЗА") { game.togglePause() })
        row2.addView(control("↺ ЗАНОВО") { game.restart() })

        root.addView(row1)
        root.addView(row2)
        setContentView(root)
    }

    private fun control(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                android.graphics.Color.rgb(75, 115, 55)))
            setOnClickListener { action() }
        }

    override fun onPause() { super.onPause(); if (::game.isInitialized) game.pause() }
}
